﻿namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-FB9RKQ9D\SQLEXPRESS;Database=Sales;Integrated Security=True;";
    }
}
