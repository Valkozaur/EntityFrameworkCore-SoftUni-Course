﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-FB9RKQ9D\SQLEXPRESS;;Database=Cinema;Trusted_Connection=True";
    }
}
