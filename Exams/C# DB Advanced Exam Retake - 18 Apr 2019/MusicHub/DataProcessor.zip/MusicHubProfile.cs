﻿using System;
using System.Globalization;
using MusicHub.Data.Models;
using MusicHub.Data.Models.Enums;
using MusicHub.DataProcessor.ImportDtos;

namespace MusicHub
{
    using AutoMapper;

    public class MusicHubProfile : Profile
    {
        // Configure your AutoMapper here if you wish to use it. If not, DO NOT DELETE THIS CLASS
        public MusicHubProfile()
        {
            //Import Writer
            CreateMap<ImportWriterDtO, Writer>();

            //Import Albums
            CreateMap<ImportAlbumDtO, Album>()
                .ForMember(x => x.ReleaseDate,
                    y => y.MapFrom(x =>
                        DateTime.ParseExact(x.ReleaseDate, "dd/MM/yyyy", CultureInfo.InvariantCulture)));

            //Import Producers
            CreateMap<ImportProducersDtO, Producer>();

            //Import Song
            CreateMap<ImportSongDtO, Song>()
                .ForMember(x => x.CreatedOn,
                    y => y.MapFrom(x => DateTime.ParseExact(x.CreatedOn, "dd/MM/yyyy", CultureInfo.InvariantCulture,
                        DateTimeStyles.None)))
                .ForMember(x => x.Duration,
                    y => y.MapFrom(x =>
                        TimeSpan.ParseExact(x.Duration, "c", CultureInfo.InvariantCulture, TimeSpanStyles.None)))
                .ForMember(x => x.Genre,
                    y => y.MapFrom(x => Enum.Parse<Genre>(x.Genre)));

            //ImportPerformer
            CreateMap<ImportPerformerDtO, Performer>()
                .ForMember(x => x.Songs, y => y.Ignore());
        }
    }
}
