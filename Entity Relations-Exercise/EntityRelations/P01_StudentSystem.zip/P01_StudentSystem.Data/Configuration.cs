﻿namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=LAPTOP-FB9RKQ9D\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
    }
}
