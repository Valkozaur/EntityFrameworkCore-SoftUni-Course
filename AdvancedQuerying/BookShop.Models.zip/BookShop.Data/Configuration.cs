﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=LAPTOP-FB9RKQ9D\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
